def somma(a, b):
    """Ritorna la somma di a e b"""
    return a + b

