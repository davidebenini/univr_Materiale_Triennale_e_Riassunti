"""Programma che definisce la variabile "n" e ne calcola e stampa il quadrato e il cubo"""
# Dati iniziali
n = 7

# Elaborazione
quadrato = 7 ** 2
cubo = 7 ** 3

# Output
print("Il quadrato di", n, "è:", quadrato)
print("Il cubo di", n, "è:", cubo)
