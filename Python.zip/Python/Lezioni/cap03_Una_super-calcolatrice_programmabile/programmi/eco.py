"""Ripete a video quello che viene inserito da tastiera"""
testo = input("Inserisci un testo: ")
print(testo)
