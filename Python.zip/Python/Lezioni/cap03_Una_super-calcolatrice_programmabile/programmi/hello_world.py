"""Il nostro primo programma in Python"""
print("Hello, World!")    # "Stampa" a video un saluto al mondo 
