"""Calcola la media di due numeri inseriti dall'utente"""
a = eval(input("Primo valore: "))
b = eval(input("Secondo valore: "))
c = eval(input("Terzo valore: "))

somma = a + b + c
media = somma / 3

print("Media aritmetica di", a, ",", b, "e" , c, ":", media)
