"""Calcola la media di due numeri inseriti dall'utente"""
a = eval(input("Primo valore: "))
b = eval(input("Secondo valore: "))

somma = a + b
media = somma / 2

print("Media aritmetica di", a, "e", b, ":", media)
