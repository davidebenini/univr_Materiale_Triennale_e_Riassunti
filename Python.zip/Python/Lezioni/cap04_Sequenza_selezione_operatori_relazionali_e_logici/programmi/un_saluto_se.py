"""Stampa "Buongiorno" solo se l'utente inserisce "s" e poi stampa "Fine" """
scelta = input("Vuoi stampare un saluto a video (s=sì)? ")

if scelta == "s":
    print("Buongiorno")

print("Fine")

