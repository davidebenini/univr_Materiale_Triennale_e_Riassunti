# Somma i due numeri interi inseriti dall'utente
a = int(input("Primo valore: "))
b = int(input("Secondo valore: "))
print(a, "+", b, "=", a + b)
