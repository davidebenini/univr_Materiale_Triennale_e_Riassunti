__author__ = "maurizio.boscaini@univr.it"
__version__ = "1.0.1"

def somma_valori(filename):
    """Somma i valori contenuti in un file di testo
    """
    somma = 0
    
    for line in open(filename):
        for value in line.split():
            somma += eval(value)
        
    return somma

if __name__ == "__main__":
    print(somma_valori("valori.txt"))    
    