"""Elenca gli impianti della lessinia"""
QUOTA_PARTENZA = 13
QUOTA_ARRIVO = 14
SEP = ","

def process_file(filename, alt_min=0, alt_max=10000):
    file = open(filename)
    header = True
    
    for line in file:
        try:
            quota_partenza = fields[QUOTA_PARTENZA]
            quota_arrivo = fields[QUOTA_ARRIVO]
            
            if int(quota_partenza) >= alt_min and int(quota_arrivo) <= alt_max:
                print(line, end="")
        except:
            print(line)
    
    file.close()


if __name__ == "__main__":
    filename = "lista_impianti.csv"
    process_file(filename, 1000, 1600)
