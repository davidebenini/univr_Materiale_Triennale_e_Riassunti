__author__ = "maurizio.boscaini@univr.it"
__version__ = "1.0.1"
from turtle import Turtle

def poligono_regolare(ninja, n):
    """Disegna un poligono regolare con n lati
    """
    ninja.goto(0, 0)
    
    for _ in range(n):
        ninja.forward(50)
        ninja.left(360 // n)

if __name__ == "__main__":
    ninja = Turtle()
    n = int(input("Numero lati:"))
    poligono_regolare(ninja, n)
    