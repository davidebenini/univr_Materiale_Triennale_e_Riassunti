__author__ = "maurizio.boscaini@univr.it"
__version__ = "1.0.1"
import string

def vowel_frequencies(filename):
    """Ritorna la frequenza delle vocali
    contenute in un file di testo
    """
    count = 0
    frequencies = {"a":0, "e":0, "o":0, "i":0, "u":0}
    
    for line in open(filename):
        for char in line.lower():
            if char in frequencies:
                frequencies[char] += 1

            if char in string.ascii_lowercase:
                count += 1
        
    for vowel in frequencies:
        frequencies[char] = frequencies[char] / count * 100
    
    return frequencies

if __name__ == "__main__":
     for vowel, freq in vowel_frequencies("1984.txt").items():
        print("{}: {}".format(char, round(freq, 2)))
    