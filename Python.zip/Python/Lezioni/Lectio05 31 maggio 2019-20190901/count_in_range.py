__author__ = "maurizio.boscaini@univr.it"
__version__ = "1.0.1"

def count_in_range(filename, value_min, value_max):
    """Conta i valori presenti in un fil compresi in un intervallo
    """
    count = 0
    
    for line in open(filename):
        for value in line.split():
            value = eval(value)

            if value_min <= value <= value_max:
                print("value:", value)
                count += 1
        
    return count

if __name__ == "__main__":
    print("count:", count_in_range("valori.txt", 9, 20))   
    
