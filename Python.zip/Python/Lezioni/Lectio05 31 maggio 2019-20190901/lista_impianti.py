"""Elenca gli impianti della lessinia"""
QUOTA_PARTENZA = 13
QUOTA_ARRIVO = 14
SEP = ","


def process_file(filename, alt_min=0, alt_max=10000):
    file = open(filename)
    header = True
    
    for line in file:
        if header:
            header = False
        else:
            values = line.split(SEP)
            quota_partenza = values[QUOTA_PARTENZA]
            quota_arrivo = values[QUOTA_ARRIVO]
            
            if quota_partenza.strip() and quota_arrivo.strip():
                if int(quota_partenza) >= alt_min and int(quota_arrivo) <= alt_max:
                    print(line, end="")
    file.close()

if __name__ == "__main__":
    filename = "lista_impianti.csv"
    process_file(filename, 1000, 1600)
