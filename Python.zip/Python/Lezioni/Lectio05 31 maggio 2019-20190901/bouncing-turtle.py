"""Fa rimbalzare uno sprite sui bordi del canvas
"""
from turtle import *
from random import randint

filename = "ninja.gif"
speed = 10
w, h = 600, 480
margin = 80

def start():
    setup(w, h)
    penup()
    register_shape(filename)
    shape(filename)
    
    while True:
        forward(speed)
        angle = randint(120, 240)
        
        if xcor() > w // 2 - margin:
            right(angle)
        elif xcor() < - w // 2 + margin:
            left(angle)
        elif ycor() > h // 2 - margin:
            right(angle)
        elif ycor() < - h // 2 + margin:
            left(angle)

if __name__ == "__main__":
    start()