import turtle
import os
from random import randint
from time import sleep

DELAY = 0.1
W, H = 800, 600

class MySprite():
    def __init__(self, x, y, shape, image_path="images"):
        self.x = x
        self.y = y
        self.shape = image_path +"/"+ shape
        self.sprite = turtle.Turtle()
        turtle.register_shape(self.shape)
        self.sprite.shape(self.shape)
        self.sprite.penup()
        self.goto(x, y)

    def goto(self, x, y):
        self.sprite.goto(x - W // 2, - y + H // 2)

if __name__ == '__main__':
    margin = 80
    screen = turtle.Screen()
    screen.setup(W, H)
    sprites = []

    for filename in os.listdir("images"):
        x = randint(margin, W - margin)
        y = randint(margin, H - margin)
        sprite = MySprite(x, y, filename)
        sprites.append(sprite)

    while True:
        for sprite in sprites:
            x = randint(margin, W - margin)
            y = randint(margin, H - margin)
            sprite.goto(x, y)

        sleep(DELAY)
