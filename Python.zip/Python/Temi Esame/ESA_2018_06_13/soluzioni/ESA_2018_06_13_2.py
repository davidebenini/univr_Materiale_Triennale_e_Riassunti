def is_prime(n):
    """dato un numero intero ritorna True se è primo,
    False in caso contrario
    >>> is_prime(37)
    True
    >>> is_prime(39)
    False
    """
    for i in range(2, n // 2):
        if n % i == 0:
            return False
    
    return True


def twin_prime_numbers(n1, n2):
    """data una coppia di numeri
    verifica se si tratta di una coppia di numeri primi gemelli,
    cioè coppie di numeri che siano primi e distino tra di loro 2
    (per es. 3 e 5, 11 e 13).
    >>> twin_prime_numbers(11, 13)
    True
    >>> twin_prime_numbers(11, 17)
    False
    """
    return is_prime(n1) and is_prime(n2) and n2 - n1 == 2

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=False)