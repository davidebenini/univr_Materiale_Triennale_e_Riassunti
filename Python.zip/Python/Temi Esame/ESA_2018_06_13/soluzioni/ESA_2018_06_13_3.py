def most_frequent(filename):
    """Ritorna una tupla col numero intero che appare più volte
    (in effetti ci potrebbero essere più numeri...)
    nel file di testo specificato e il numero delle sue occorrenze
    >>> most_frequent('dati.txt')  # Il 39 appare 6 volte
    (39, 6)
    """
    frequencies = {}
    count = 1

    for line in open(filename):
        values = line[:-1].split(" ")

        for value in values:
            value = int(value)

            if value in frequencies:
                frequencies[value] += 1
            else:
                frequencies[value] = 1
        count += 1

    _max = 0
    _value = None

    for key, value in frequencies.items():
        if _value is None or value > _value:
            _max = key
            _value = value

    return _max, _value

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
