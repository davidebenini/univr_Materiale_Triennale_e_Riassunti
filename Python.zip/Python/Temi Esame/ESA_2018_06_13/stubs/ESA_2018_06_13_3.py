def most_frequent(filename):
    """Ritorna una tupla col numero intero che appare più volte
    nel file di testo specificato e il numero delle sue occorrenze
    >>> most_frequent('dati.txt')  # Il 39 appare 5 volte
    (39, 5)
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
