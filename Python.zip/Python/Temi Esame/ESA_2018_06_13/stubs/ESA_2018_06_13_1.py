def multiple_of(n, _from, _to):
    """Ritorna True se il numero intero n è divisibile
    per tutti gli interi nell'intervallo [_from, _to],
    False in caso contrario.
    >>> multiple_of(2520, 1, 10)
    True
    >>> multiple_of(12420, 1, 10)
    False
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
