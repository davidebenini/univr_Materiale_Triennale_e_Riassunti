def max_length_sequence(filename, char):
    """Ritorna la lunghezza massima di una sequenza di char
    nel file di testo specificato.
    >>> max_length_sequence('dna.txt', 'A')
    4
    >>> max_length_sequence('dna.txt', 'G')
    2
    """
    count = 0
    max_count = 0
    file = open(filename)
    text = file.read()
    i = 0

    while i < len(text):
        count = 0
        
        while i < len(text) and text[i] == char:
            count += 1
            i += 1    

        if count > max_count:
            max_count = count

        i += 1

    file.close()
    return max_count

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
