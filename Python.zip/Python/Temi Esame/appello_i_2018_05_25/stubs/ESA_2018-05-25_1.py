def fibonacci(n):
    """Restituisce l'n-simo valore della successione di Fibonacci
    >>> fibonacci(0)
    0
    >>> fibonacci(10)
    55
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
