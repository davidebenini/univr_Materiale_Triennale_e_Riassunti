def count_char(filename, char):
    """Ritorna il numero di occorrenze di char
    nel file di testo specificato.
    >>> count_char('dna.txt', 'A')
    12
    >>> count_char('dna.txt', 'G')
    4
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
