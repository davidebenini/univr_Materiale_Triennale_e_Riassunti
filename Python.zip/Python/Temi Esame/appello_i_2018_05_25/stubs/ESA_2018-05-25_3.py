def max_length_sequence(filename, char):
    """Ritorna la lunghezza massima di una sequenza di char
    nel file di testo specificato.
    >>> max_length_sequence('dna.txt', 'A')
    4
    >>> max_length_sequence('dna.txt', 'G')
    2
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
