def sum_by_column(filename, n, sep=","):
    """Ritorna la somma dei valori della colonna specificata 
    di un file CSV con riga iniziale di intestazione
    >>> sum_by_column("carriage_services_inc.csv", 2)
    601.24
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=False)
