def factorial(n):
    """Restituisce il fattoriale di un numero n
    >>> factorial(0)
    1
    >>> factorial(6)
    720
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
