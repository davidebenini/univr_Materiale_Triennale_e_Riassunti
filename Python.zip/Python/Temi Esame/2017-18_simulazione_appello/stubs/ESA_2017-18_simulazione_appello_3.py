def count_in_range(filename, n, inf, sup, sep=","):
    """Ritorna il numero di valori compresi nell'intervallo [inf, sup]
    presenti nella colonna specificata
    di un file CSV con riga iniziale di intestazione.
    >>> count_in_range("carriage_services_inc.csv", 1, 26, 27.5)
    7
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=False)
