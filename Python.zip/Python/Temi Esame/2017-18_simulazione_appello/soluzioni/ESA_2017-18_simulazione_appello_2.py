def sum_by_column(filename, n, sep=","):
    """Ritorna la somma dei valori della colonna specificata 
    di un file CSV con riga iniziale di intestazione
    >>> sum_by_column("carriage_services_inc.csv", 2)
    601.24
    """
    _sum = 0
    file = open(filename)
    lines = file.readlines()[1:]
    
    for line in lines:
        values = line.split(sep)
        _sum += float(values[n])

    return _sum

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=False)
