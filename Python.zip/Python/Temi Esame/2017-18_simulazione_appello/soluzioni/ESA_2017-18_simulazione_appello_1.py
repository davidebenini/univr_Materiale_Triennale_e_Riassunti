def factorial(n):
    """Restituisce il fattoriale di un numero n
    >>> factorial(0)
    1
    >>> factorial(6)
    720
    """
    if n == 0:
        return 1
    else:
        return n * factorial(n - 1)

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
