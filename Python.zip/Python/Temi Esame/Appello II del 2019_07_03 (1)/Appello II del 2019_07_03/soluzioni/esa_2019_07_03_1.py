"""Programma per il calcolo del valore di pi greco"""
from math import sin, cos, pi

def definite_integral(f, a, b, n):
    """Restituisce il valore dell'integrale definito della funzione f
    nell'intervallo [a, b] con n passi o suddivisioni.
    Per calcolare il rettangolo i-simo si consideri come altezza
    il valore della funzione nel punto medio della base.
    >>> definite_integral("x", 0, 1, 10000)
    0.4999999999999602
    >>> definite_integral("sin(x)", 0, pi, 10000)
    2.000000008224376
    """
    _sum = 0
    dx = (b - a) / n
    x = a + dx / 2

    while x <= b:
        _sum += eval(f) * dx
        x += dx

    return _sum

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
