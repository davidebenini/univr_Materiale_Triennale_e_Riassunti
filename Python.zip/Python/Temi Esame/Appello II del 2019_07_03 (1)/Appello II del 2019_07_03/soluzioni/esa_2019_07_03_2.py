"""
Source:
Climate Change: Earth Surface Temperature Data
Exploring global temperatures since 1750
Berkeley Earth
License CC BY-NC-SA 4.0
data.csv

Record layout:
dt,AverageTemperature,AverageTemperatureUncertainty,Country
"""
def average_temperature(filename, country, sep=","):
    """Restituisce la media delle temperature di una nazione.
    >>> average_temperature("data.csv", "Italy")
    12.737121920404292
    >>> average_temperature("data.csv", "Tanzania")
    22.347910971786856
    """
    _sum = 0
    count = 0

    for line in open(filename):
        values = line[:-1].split(sep)
        temperature = values[1]
        _country = values[3]

        if country == _country and temperature:
            _sum += float(temperature)
            count += 1

    return _sum / count

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
