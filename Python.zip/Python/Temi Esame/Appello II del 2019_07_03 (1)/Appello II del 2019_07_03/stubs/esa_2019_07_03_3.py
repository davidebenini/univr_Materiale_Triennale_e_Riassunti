"""Stampa un grafico in stile ASCII art con la media delle temperature di una lista di nazioni.
"""
from esa_2019_07_03_2 import average_temperature

def print_average_chart(filename, countries, symbol="*"):
    """Stampa un grafico in stile ASCII art
    con la media delle temperature di una lista di nazioni.
    >>> print(print_average_chart("data.csv", ("Italy", "Tanzania")))
    Italy 12.74 *************
    Tanzania 22.35 **********************
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
