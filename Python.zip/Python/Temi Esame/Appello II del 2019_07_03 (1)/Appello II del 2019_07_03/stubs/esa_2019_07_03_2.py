"""
Source:
Climate Change: Earth Surface Temperature Data
Exploring global temperatures since 1750
Berkeley Earth
License CC BY-NC-SA 4.0
data.csv

Record layout:
dt,AverageTemperature,AverageTemperatureUncertainty,Country
"""
def average_temperature(filename, country, sep=","):
    """Restituisce la media delle temperature di una nazione.
    >>> average_temperature("data.csv", "Italy")
    12.737121920404292
    >>> average_temperature("data.csv", "Tanzania")
    22.347910971786856
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
