-- Esercitazione 1
-- ES 1
DROP TABLE opera;
DROP TABLE orario;
DROP TABLE mostra;
DROP TABLE museo;
DROP DOMAIN settimana;
DROP DOMAIN price;
CREATE DOMAIN settimana AS VARCHAR(3)
CHECK (VALUE IN('lun','mar','mer','gio','ven','sab','dom'));

CREATE DOMAIN price AS NUMERIC(5,2) CHECK (VALUE >=0);


CREATE TABLE Museo(
	nome 			VARCHAR(30)		DEFAULT 'MuseoVeronese',
	citta 			VARCHAR(20)		DEFAULT 'Verona',
	indirizzo		VARCHAR(20),
	numeroTelefono	VARCHAR(20), 	-- possiamo dover aggiungere 
									--il prefisso nazionale e quindi sto largo
	giornoChiusura	settimana 		NOT NULL,
	prezzo			price			NOT NULL	DEFAULT 10.00,
	PRIMARY KEY(nome,citta)
);

CREATE TABLE Mostra(
	titolo			VARCHAR(30),
	inizio 			DATE			NOT NULL,
	fine			DATE			NOT NULL check (fine > inizio),-- ci sarebbe il confronto con mostra.inizio da fare
	museo 			VARCHAR(30),
	citta			VARCHAR(20),
	prezzo			price,
	PRIMARY KEY(titolo, inizio),
	FOREIGN KEY(museo,citta) REFERENCES Museo
		ON UPDATE SET DEFAULT ON DELETE SET DEFAULT
);

CREATE TABLE Opera(
	nome 			VARCHAR(30),
	cognomeAutore	VARCHAR(20),
	nomeAutore		VARCHAR(20),
	museo 			VARCHAR(30),
	citta			VARCHAR(20),
	epoca			VARCHAR(20),-- considero epoca impressionismo...
	anno			INTEGER CHECK (anno < 2018),
	PRIMARY KEY(nome, cognomeAutore, nomeAutore),
	FOREIGN KEY(museo,citta) REFERENCES Museo 
		ON UPDATE CASCADE ON DELETE SET NULL
);
CREATE TABLE Orario(
	progressivo 	INTEGER PRIMARY KEY,
	museo 			VARCHAR(30)		NOT NULL,
	citta			VARCHAR(20)		NOT NULL,
	giorno 			settimana		NOT NULL,
	orarioApertura	TIME WITH TIME ZONE 	DEFAULT '09:00:00 CET',
	orarioChiusura	TIME WITH TIME ZONE		DEFAULT '19:00:00 CET',
	FOREIGN KEY(museo,citta) REFERENCES Museo
		ON UPDATE CASCADE ON DELETE CASCADE
);

--------------------ES 2-----------------------------

INSERT INTO Museo(nome, citta, indirizzo, numeroTelefono, giornoChiusura, prezzo)
	VALUES('Arena', 'Verona', 'piazza Bra', '045 8003204', 'mar', 20),
			('CastelVecchio', 'Verona', 'Corso Castelvecchio', '045 594734', 'lun', 15);

-----------------ES 3-----------------------------

INSERT INTO Opera(nome, cognomeAutore, nomeAutore, museo, citta, epoca, anno)
	VALUES('Gioconda', 'DaVinci', 'Leonardo', 'Arena', 'Verona', 'Rinascimento', '1503'),
		('Notte Stellata', 'Van Gogh', 'Vincent', 'Arena', 'Verona', 'Post-Impressionismo' , '1889'),
			('La scuola di Atene', 'Sanzio', 'Raffaello', 'CastelVecchio', 'Verona', 'Alto Rinascimento' , '1509');

INSERT INTO Mostra(titolo, inizio, fine, museo, citta, prezzo)
	VALUES('OperaBella','2015/03/10','2020/07/03','Arena','Verona', 25.00),
		('I grandi del passato','2012/12/23','2013/05/03','CastelVecchio','Verona', NULL),
		('Mostra per pochi','2018/11/11','2020/04/07','Arena','Verona', 500.00);

INSERT INTO Orario(progressivo, museo, citta, giorno, orarioApertura)
	VALUES(0, 'Arena', 'Verona', 'lun', NULL);


INSERT INTO Orario(progressivo, museo, citta, giorno)
	VALUES(1, 'Arena', 'Verona', 'mar');

INSERT INTO Orario(progressivo, museo, citta, giorno)
	VALUES(2, 'Arena', 'Verona', 'mer');
-----------------ES 4-----------------------------

--INSERT INTO Museo(nome, citta, indirizzo, numeroTelefono, giornoChiusura, prezzo)--errore nel telefono nells giorno e nel prezzo
--VALUES ('?','Parma','via aquileia', 'asd', 'SAB', 10000);

--INSERT INTO Mostra(titolo, inizio, fine, museo, citta, prezzo)
--VALUES	('ciaonee','2015/03/10','2013/05/03','Arena','Verona', 25.00);-- data iniziale dopo data


-----------------ES 5-----------------------------

ALTER TABLE Museo ADD COLUMN sitoInternet VARCHAR(50);
--popolo la colonna sitoInternet in relazione alla chiave
UPDATE Museo
	SET sitoInternet = 'http://www.arenamuseopera.com/en/'
	WHERE nome = 'Arena' AND citta = 'Verona'; -- setto il primary key
UPDATE Museo
	SET sitoInternet = 'https://museodicastelvecchio.comune.verona.it'
WHERE nome = 'CastelVecchio' AND citta = 'Verona';--metto il Primary key

-----------------ES 6----------------------------

ALTER TABLE Mostra RENAME prezzo TO prezzoIntero; 
ALTER TABLE Mostra ADD COLUMN prezzoRidotto price CHECK (prezzoRidotto < prezzoIntero);
ALTER TABLE Mostra ALTER COLUMN prezzoRidotto
	SET DEFAULT 5.00; 

-----------------ES 7----------------------------
UPDATE Museo
	SET prezzo = prezzo + 1.00

-----------------ES 8----------------------------

UPDATE Mostra
	SET prezzoRidotto = prezzoRidotto + 1.00
	WHERE prezzoIntero < 15.00

































