--Esercitaione 2
--Ogni volta che c'è una query bisogna chiedersi:
--1) Cosa si chiede
--2) Chi sono le tabelle che hanno queste informazioni
--3) Scrivere le proprietà che servono per raffinare le informazioni e stampare così solo le informazioni richieste

-----------------------ES 1---------------------------
--Visualizzare tutti i musei della città di Verona con il loro giorno di chiusura.

--SELECT nome, citta, giornoChiusura
--FROM Museo
--WHERE LOWER(citta) = 'verona';



-----------------------ES 2-----------------------------
--Visualizzare per ogni mostra che inizia con la lettera ’R’, una stringa composta dal titolo e dalla città in cui si svolge

--SELECT M1.titolo, M2.citta
--FROM Mostra AS M1, Museo AS M2
--WHERE titolo LIKE 'R%';




-----------------------ES 3--------------------------
--Visualizzare il titolo di ogni mostra ancora in corso e quanti giorni rimane ancora aperta a partire dalla data corrente. Usare la costante CURRENT_DATE per avere la data corrente

--SELECT titolo, inizio, fine, fine - CURRENT_DATE AS "GiornifineMostra"
--FROM Mostra
--WHERE CURRENT_DATE BETWEEN inizio AND fine;



-----------------------ES 4---------------------------
--Visualizzare per ogni museo l’orario di apertura e chiusura il martedì. Se per un museo il ma-rtedì è giorno di chiusura, non mostrare nulla.

--SELECT nome, orarioApertura, orarioChiusura, giorno
--FROM Museo, Orario
--WHERE giorno = 'mar';

-----------------------ES 5---------------------------
--Assicurarsi che almeno una mostra abbia il prezzo ridotto non valorizzato (NULL) usando eventualmente il comando UPDATE per modificare almeno una riga.. Visualizzare tutte le mostre che hanno prezzo ridotto non valorizzato usando prima l’espressione ERRATA ’prezzoRidotto = NULL’ e poi l’espressione corretta prezzoRidotto IS NULL.

--SELECT titolo, inizio, prezzoRidotto
--FROM Mostra
--WHERE prezzoRidotto IS NULL;


-----------------------ES 6---------------------------
--Visualizzare tutte le mostre non terminate in ordine di data inizio e, in caso di pari data inizio, data fine.

--SELECT titolo, inizio, fine
--FROM Mostra
--WHERE fine < CURRENT_DATE
--GROUP BY titolo, inizio, fine;


-----------------------ES 7---------------------------
--Visualizzare il numero totale di giorni di apertura del museo ’Arena’ di ’Verona’;
--SELECT COUNT(giorno) AS "Giorni Apertura Arena di Verona"
--FROM Orario
--WHERE museo = 'Arena' AND citta = 'Verona' AND orarioApertura IS NOT NULL;

-----------------------ES 8---------------------------
--Visualizzare le ore medie di apertura del museo ’Arena’ di ’Verona’. Suggerimento: convertire orarioapertura e orariochiusure usando ’::time’.
--SELECT AVG(orarioChiusura::time - orarioApertura::time) AS "Media apertura della settimana"
--FROM Orario
--WHERE museo = 'Arena' AND citta = 'Verona';


-----------------------ES 9---------------------------
--Indicare il numero di autori distinti presenti in tutti i musei.
SELECT DISTINCT COUNT(nomeAutore) AS "Numero di autori nei musei"
FROM Opera AS o1, Opera AS o2
WHERE o1.nomeAutore <> o2.nomeAutore;































