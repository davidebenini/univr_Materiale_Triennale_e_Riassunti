--Esercitazione 5
-------------------------ES 3--------------------------
--Trovare, per ogni insegnamento erogato dell’a.a. 2013/2014, il suo nome e id della facoltà che lo gestisce usando
--la relazione assorbita con facoltà.

EXPLAIN SELECT DISTINCT I.nomeins, IE.id_facolta
FROM Insegn I 
	JOIN InsErogato IE ON(IE.id_insegn = I.id)
WHERE IE.annoaccademico = '2013/2014';

DROP INDEX ind_annoacca;
CREATE INDEX ind_annoacca ON InsErogato (annoaccademico varchar_pattern_ops);-- varchar_pattern_ops 
--permette di considerare anche operatori del tipo LIKE 'stringa%'

ANALYZE InsErogato;

EXPLAIN SELECT DISTINCT I.nomeins, IE.id_facolta
FROM Insegn I 
	JOIN InsErogato IE ON(IE.id_insegn = I.id)
WHERE IE.annoaccademico = '2013/2014';


-----------------------ES 4---------------------------
--Visualizzare il codice, il nome e l’abbreviazione di tutti corsi di studio che nel nome contengono la sottostringa
--’lingue’ (eseguire un test case-insensitive: usare ILIKE invece di LIKE ).

DROP INDEX nome_idx;
EXPLAIN SELECT codice, nome, abbreviazione
FROM CorsoStudi
WHERE nome ILIKE '%lingue%';

CREATE INDEX nome_idx ON CorsoStudi(nome varchar_pattern_ops);

ANALYZE CorsoStudi;
EXPLAIN SELECT CS.codice, CS.nome, CS.abbreviazione
FROM CorsoStudi CS 
WHERE CS.nome ILIKE '%lingue%';



-----------------------ES 5---------------------------
--Visualizzare identificatori e numeromodulo dei moduli reali degli insegnamenti erogati nel 2010/2011 associati
--alla facoltà con id=7 tramite la relazione diretta.
--Soluzione: da ~6310 accessi si passa a ~2041/1313 creando 3 indici.
DROP INDEX ind_annoacca;
EXPLAIN SELECT IE.id, IE.nomemodulo
FROM InsErogato IE
WHERE IE.annoaccademico = '2010/2011'
	AND IE.id_facolta = 7
	AND Ie.modulo > 0;

CREATE INDEX ind_annoacca ON InsErogato(annoaccademico varchar_pattern_ops);
CREATE INDEX ind_id_fac ON InsErogato(id_facolta);
CREATE INDEX ind_modulo ON InsErogato(modulo);

ANALYZE InsErogato;

EXPLAIN SELECT IE.id, IE.nomemodulo
FROM InsErogato IE
WHERE IE.annoaccademico = '2010/2011'
	AND IE.id_facolta = 7
	AND Ie.modulo > 0;



-----------------------ES 6---------------------------
--Visualizzare il nome e il discriminante (attributo descrizione della tabella Discriminante) degli insegnamenti
--erogati nel 2009/2010 che non sono moduli e che hanno 3, 5 o 12 crediti.

--EXPLAIN SELECT I.nomeins, D.descrizione
--FROM Discriminante D 
--	JOIN InsErogato IE ON (D.id = IE.id_discriminante)
--	JOIN Insegn I ON (IE.id_insegn = I.id)
--WHERE IE.annoaccademico = '2009/2010' AND IE.modulo = 0 AND IE.crediti IN (3,5,12);

CREATE INDEX triplo ON inserogato(annoaccademico varchar_pattern_ops, modulo, crediti);
ANALYZE InsErogato;

EXPLAIN SELECT I.nomeins, D.descrizione
FROM Discriminante D 
	JOIN InsErogato IE ON (D.id = IE.id_discriminante)
	JOIN Insegn I ON (IE.id_insegn = I.id)
WHERE IE.annoaccademico = '2009/2010' AND IE.modulo = 0 AND IE.crediti IN (3,5,12);



-----------------------ES 7---------------------------

--Visualizzare il nome e il discriminante degli insegnamenti erogati nel 2008/2009 senza moduli e con crediti
--maggiore di 9.

--DROP INDEX triplo;
--EXPLAIN SELECT I.nomeins, D.descrizione
--FROM Insegn I 
--	JOIN InsErogato IE ON (I.id = IE.id_insegn)
--	JOIN Discriminante D ON (IE.id_discriminante = D.id)
--WHERE IE.annoaccademico = '2008/2009' AND
--	IE.hamoduli = '0' AND  --è un varchar
--	IE.crediti > 9;
	
CREATE INDEX triploo ON InsErogato (annoaccademico varchar_pattern_ops, hamoduli, crediti);
ANALYZE InsErogato;

EXPLAIN SELECT I.nomeins, D.descrizione
FROM Insegn I 
	JOIN InsErogato IE ON (I.id = IE.id_insegn)
	JOIN Discriminante D ON (IE.id_discriminante = D.id)
WHERE IE.annoaccademico = '2008/2009' AND
	IE.hamoduli = '0' AND  --è un varchar
	IE.crediti > 9;


-----------------------ES 8---------------------------
--Visualizzare in ordine alfabetico di nome degli insegnamenti (esclusi di moduli e le unità logistiche) erogati
--nel 2013/2014 nel corso di ’Laurea in Informatica’, riportando il nome, il discriminante, i crediti e gli anni di
--erogazione.

DROP INDEX ind_cs_id;
DROP INDEX ind_IE_id_corsostudi;
DROP INDEX ind_INS_id;
DROP INDEX index_tanta_roba;


EXPLAIN SELECT I.nomeins, D.descrizione, IE.crediti, IE.annoaccademico
FROM Insegn I
	JOIN InsErogato IE ON(I.id = IE.id_insegn)
	JOIN Discriminante D ON(IE.id_discriminante = D.id)
	JOIN CorsoStudi CS ON(Ie.id_corsostudi = CS.id)
WHERE IE.modulo = 0
	AND CS.nome ILIKE 'Laure in informatica'
	AND IE.annoaccademico = '2013/2014'
ORDER BY I.nomeins ASC;
--6722
CREATE INDEX ind_cs_id  ON CorsoStudi (id);
CREATE INDEX ind_IE_id_corsostudi ON InsErogato(id_corsostudi); --dopo questi due indici --> 838
CREATE INDEX ind_INS_id ON Insegn (id);--408
 
CREATE INDEX index_tanta_roba  ON InsErogato (modulo, annoaccademico varchar_pattern_ops) WHERE annoaccademico = '2013/2014' AND modulo = 0;

-----------------------ES 9---------------------------
--Trovare il massimo numero di crediti degli insegnamenti erogati dall’ateneo nell’a.a. 2013/2014.

--EXPLAIN SELECT MAX(crediti)
--FROM InsErogato
--WHERE annoaccademico = '2013/2014';
DROP INDEX anno_idx;

CREATE INDEX crediti_idx ON InsErogato(crediti);
CREATE INDEX anno_idx ON InsErogato(annoaccademico varchar_pattern_ops);

ANALYZE InsErogato;
EXPLAIN SELECT MAX(crediti)
FROM InsErogato
WHERE annoaccademico = '2013/2014';



-----------------------ES 10---------------------------
--Trovare, per ogni anno accademico, il massimo e il minimo numero di crediti erogati in un insegnamento.

--EXPLAIN SELECT MAX(crediti) AS MassimoCrediti, MIN(crediti) AS MinimoCrediti, COUNT(crediti) AS NumeroCrediti
--FROM InsErogato;
DROP INDEX crediti_idx2;
CREATE INDEX crediti_idx2 ON InsErogato(crediti);

ANALYZE InsErogato;
EXPLAIN SELECT MAX(crediti) AS MassimoCrediti, MIN(crediti) AS MinimoCrediti, COUNT(crediti) AS NumeroCrediti
FROM InsErogato;


------------------------ES 11--------------------------
--Trovare il nome dei corsi di studio che non hanno mai erogato insegnamenti che contengono nel nome la stringa
--’matematica’ (usare ILIKE invece di LIKE per rendere il test non sensibile alle maiuscole/minuscole).

DROP INDEX ind_nomeins;
DROP INDEX ind_id_insegn;
DROP INDEX ind_IE_id_corsostudi;
DROP INDEX ind_CS_id;

EXPLAIN SELECT CS.nome, I.nomeins
FROM InsErogato IE 
	JOIN Insegn I ON(IE.id_insegn = I.id)
	JOIN CorsoStudi CS ON(IE.id_corsostudi =CS.id)
WHERE I.nomeins NOT ILIKE '%matematica%';
--9142
CREATE INDEX ind_nomeins ON Insegn (nomeins varchar_pattern_ops);
CREATE INDEX ind_id_insegn ON Insegn (id);
CREATE INDEX ind_IE_id_corsostudi ON InsErogato(id_corsostudi);
CREATE INDEX ind_CS_id ON CorsoStudi (id);

ANALYZE Insegn;

EXPLAIN SELECT CS.nome, I.nomeins
FROM InsErogato IE 
	JOIN Insegn I ON(IE.id_insegn = I.id)
	JOIN CorsoStudi CS ON(IE.id_corsostudi =CS.id)
WHERE I.nomeins NOT ILIKE '%matematica%';


-----------------------ES 12--------------------------
--Trovare, per ogni anno accademico e per ogni corso di laurea, la somma dei crediti erogati (esclusi i moduli e le
--unità logistiche: vedi nota sopra) e il massimo e minimo numero di crediti degli insegnamenti erogati sempre
--escludendo i moduli e le unità logistiche.
--Soluzione: da ~7408 accessi si passa a...
DROP INDEX ind_modulo;
DROP INDEX ind_crediti;
EXPLAIN SELECT IE.annoaccademico, CS.nome, SUM(IE.crediti) AS sommacrediti, MAX(IE.crediti),MIN(IE.crediti)
FROM InsErogato IE
	JOIN CorsoStudi CS ON ( IE.id_corsostudi = CS.id)
WHERE IE.modulo = 0
GROUP BY (IE.annoaccademico, CS.nome);
	--incredibile! esattamente 7408 lel

CREATE INDEX ind_modulo ON InsErogato(modulo);
CREATE INDEX ind_crediti ON InsErogato(crediti);
ANALYZE InsErogato;


EXPLAIN SELECT IE.annoaccademico, CS.nome, SUM(IE.crediti) AS sommacrediti, MAX(IE.crediti),MIN(IE.crediti)
FROM InsErogato IE
	JOIN CorsoStudi CS ON ( IE.id_corsostudi = CS.id)
WHERE IE.modulo = 0
GROUP BY (IE.annoaccademico, CS.nome);


































