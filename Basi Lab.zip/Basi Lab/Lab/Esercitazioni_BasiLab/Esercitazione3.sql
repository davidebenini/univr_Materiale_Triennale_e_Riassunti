--Esercitazione 3

-----------------------ES 1---------------------------
--Visualizzare il numero di corso studi presenti nella base di dati.

SELECT COUNT(id)
FROM CorsoStudi;


-----------------------ES 2-----------------------------
--Visualizzare il nome, il codice, l’indirizzo e l’identificatore del preside di tutte le facoltà.

SELECT nome, indirizzo, codice, id_preside_persona
FROM Facolta;


-----------------------ES 3--------------------------
--Trovare per ogni corso di studi che ha erogato insegnamenti nel 2010/2011 il suo nome e il nome delle facoltà che lo gestiscono (si noti che un corso può essere gestito da più facoltà). Non usare la relazione diretta tra InsErogato e Facoltà. Porre i risultati in ordine di nome corso studi.

SELECT CS.nome, F.nome
FROM inserogato I
	JOIN corsostudi CS ON (I.id_corsostudi = CS.id)
	JOIN corsoinfacolta CF ON (CS.id = CF.id_corsostudi)
	JOIN facolta F ON (CF.id_facolta = F.id)
WHERE I.annoaccademico = '2011/2012'
ORDER BY CS.nome;


-----------------------ES 4---------------------------
--Visualizzare il nome, il codice e l’abbreviazione di tutti i corsi di studio gestiti dalla facoltà di Medicina e Chirurgia.

SELECT CS.nome, CS.codice, CS.abbreviazione
FROM corsostudi CS
	JOIN corsoinfacolta CF ON (CS.id = CF.id_corsostudi)
	JOIN facolta F ON(CF.id_facolta = F.id)
WHERE F.nome = 'Medicina e Chirurgia';

-----------------------ES 5---------------------------
--Visualizzare il codice, il nome e l’abbreviazione di tutti corsi di studio che nel nome contengono la sottostringa
--’lingue’ (eseguire il confronto usando ILIKE invece di LIKE : in questo modo i caratteri maiuscolo e minuscolo
--non sono diversi).

SELECT  CS.codice, CS.nome, CS.abbreviazione
FROM corsostudi CS 
WHERE CS.nome ILIKE '%lingue%';
	


-----------------------ES 6---------------------------
--Visualizzare le sedi dei corsi di studi in un elenco senza duplicati.

SELECT DISTINCT sede
FROM corsostudi


-----------------------ES 7---------------------------
--Visualizzare i moduli degli insegnamenti erogati nel 2010/2011 nei corsi di studi della facoltà di Economia.
--Si visualizzi il nome dell’insegnamento, il discriminante (attributo descrizione della tabella Discriminante), il
--nome del modulo e l’attributo modulo.
--Soluzione: ci sono 299 righe.

SELECT DISTINCT Ins.nomeins AS nome, D.descrizione AS Descr, I.nomemodulo,  I.modulo
FROM discriminante D
	JOIN inserogato I ON (D.id = I.id_discriminante)
	JOIN facolta F ON (I.id_facolta = F.id)
	JOIN insegn Ins ON (I.id_insegn = Ins.id)
WHERE I.annoaccademico = '2010/2011' AND 
	F.nome = 'Economia';

-----------------------ES 8---------------------------
--Visualizzare il nome e il discriminante (attributo descrizione della tabella Discriminante) degli insegnamenti
--erogati nel 2009/2010 che non sono moduli o unità logistiche e che hanno 3, 5 o 12 crediti. Si ordini il risultato
--per discriminante.

SELECT DISTINCT I.nomeins AS NomeInsegnamento, D.descrizione AS Descrizione
FROM discriminante D
	JOIN inserogato IE ON (D.id = IE.id_discriminante)
	JOIN insegn I ON (IE.id_insegn = I.id)
WHERE IE.annoaccademico = '2009/2010' AND IE.modulo = 0 AND IE.crediti IN (3,5,12)
GROUP BY D.descrizione, I.nomeins;


-----------------------ES 9---------------------------
--Visualizzare l’identificatore, il nome e il discriminante degli insegnamenti erogati nel 2008/2009 che non sono
--moduli o unità logistiche e con peso maggiore di 9 crediti. Ordinare per nome.

SELECT I.id, I.nomeins, D.descrizione
FROM discriminante D
	JOIN inserogato IE ON (D.id = IE.id_discriminante)
	JOIN insegn I ON (IE.id_insegn = I.id)
WHERE IE.annoaccademico = '2008/2009' AND IE.modulo = 0 AND IE.crediti > 9
ORDER BY D.descrizione;

-----------------------ES 10---------------------------
--Visualizzare in ordine alfabetico di nome degli insegnamenti (esclusi i moduli e le unità logistiche) erogati
--nel 2010/2011 nel corso di studi in Informatica, riportando il nome, il discriminante, i crediti e gli anni di
--erogazione.

SELECT I.nomeins, D.descrizione, IE.crediti, IE.annierogazione
FROM discriminante D
	JOIN inserogato IE ON (D.id = IE.id_discriminante)
	JOIN insegn I ON (IE.id_insegn = I.id)
	JOIN corsostudi CS ON (IE.id_corsostudi = CS.id)
WHERE IE.annoaccademico = '2010/2011' AND IE.modulo = 0 AND CS.nome ILIKE 'Laurea in Informatica'
ORDER BY I.nomeins;


-----------------------ES 11--------------------------
--Trovare il massimo numero di crediti associato a un insegnamento fra quelli erogati nel 2010/2011.

SELECT MAX(crediti)
FROM inserogato
WHERE annoaccademico = '2010/2011';

-----------------------ES 12--------------------------
--Trovare, per ogni anno accademico, il massimo e il minimo numero di crediti erogati tra gli insegnamenti 
--dell’anno.

SELECT MAX(IE.crediti), MIN(IE.crediti)
FROM inserogato IE
GROUP BY IE.annoaccademico


-----------------------ES 13---------------------------
--Trovare, per ogni anno accademico e per ogni corso di studi la somma dei crediti erogati (esclusi i moduli e le
--unità logistiche: vedi nota sopra) e il massimo e minimo numero di crediti degli insegnamenti erogati sempre
--escludendo i moduli e le unità logistiche

SELECT CS.nome, IE.annoaccademico, SUM(IE.crediti), MAX(IE.crediti), MIN(IE.crediti)
FROM inserogato IE
	JOIN insegn I ON (IE.id_insegn = I.id)
	JOIN corsostudi CS ON (IE.id_corsostudi = CS.id)
WHERE IE.modulo = 0
GROUP BY IE.annoaccademico, CS.nome;


-----------------------ES 14---------------------------
--Trovare per ogni corso di studi della facoltà di Scienze Matematiche Fisiche e Naturali il numero di insegnamenti
--(esclusi i moduli e le unità logistiche) erogati nel 2009/2010

SELECT DISTINCT CS.nome
FROM corsostudi CS
	JOIN inserogato IE ON (CS.id = IE.id_corsostudi)
	JOIN facolta F ON (IE.id_facolta = F.id)
WHERE F.nome ILIKE 'Scienze Matematiche Fisiche e Naturali' AND IE.modulo = 0 AND IE.annoaccademico = '2009/2010'
GROUP BY CS.nome;


-----------------------ES 15---------------------------
--Trovare i corsi di studi che nel 2010/2011 hanno erogato insegnamenti con un numero di crediti pari a 4 o 6 o
--8 o 10 o 12 o un numero di crediti di laboratorio tra 10 e 15 escluso, riportando il nome del corso di studi e la
--sua durata. Si ricorda che i crediti di laboratorio sono rappresentati dall’attributo creditilab della tabella
--InsErogato.

SELECT CS.nome, CS.durataanni
FROM corsostudi CS
	JOIN inserogato IE ON(CS.id = IE.id_corsostudi)
	JOIN insegn I ON (IE.id_insegn = I.id)
WHERE IE.annoaccademico = '2010/2011' AND (IE.crediti IN (4,6,8,10,12) OR IE.creditilab BETWEEN 11 AND 14)
GROUP BY CS.nome, CS.durataanni;




























