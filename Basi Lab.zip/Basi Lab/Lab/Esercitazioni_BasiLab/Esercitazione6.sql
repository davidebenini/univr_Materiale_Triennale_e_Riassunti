--Esercitazione 6



