--Esercitazione 3

-----------------------ES 1---------------------------
--Trovare nome, cognome dei docenti che nell’anno accademico 2010/2011 erano docenti in almeno due corsi di
--studio (vale a dire erano docenti in almeno due insegnamenti o moduli A e B dove A è del corso C 1 e B è del
--corso C 2 con C 1 6 = C 2 ).


CREATE TEMP VIEW ES1 AS 					--Con questa View trovo tutti i nomi e cognomi dei docenti che hanno tenuto un corso nel 2010/2011
	SELECT P.id AS idPersona, P.nome, P.cognome, CS.id AS idCorso
		FROM Persona P 
		JOIN Docenza D ON(P.id = D.id_persona)
		JOIN InsErogato I ON(D.id_inserogato = I.id)
		JOIN CorsoStudi CS ON(I.id_corsostudi = CS.id)
	WHERE I.annoaccademico = '2010/2011'
	GROUP BY (P.id, P.nome, P.cognome, CS.id)

SELECT idPersona, nome, cognome				--Tramite la Select sulla precedente view trovo i docenti contando il proprio ID che appaiano 2 volte e che quindi
FROM ES1						--hanno insegnato in almeno due corsi diversi
GROUP BY (idPersona, nome, cognome)
HAVING COUNT(idPersona)>= 2
ORDER BY idPersona

-----------------------ES 2-----------------------------
--Trovare nome, cognome e telefono dei docenti che hanno tenuto nel 2009/2010 un’occorrenza di insegna-
--mento che non sia un’unità logistica del corso di studi con id=4 ma che non hanno mai tenuto un modulo
--dell’insegnamento di ’Programmazione’ del medesimo corso di studi.

DROP VIEW ES2;
CREATE TEMP VIEW ES2 AS
	SELECT P.id, P.nome, P.cognome, P.telefono
	FROM persona P 
		JOIN docenza D ON (P.id = D.id_persona)
		JOIN inserogato IE ON (D.id_inserogato = IE.id)
		JOIN insegn I ON (IE.id_insegn = I.id)
	WHERE I.nomeins ILIKE 'Programmazione' AND IE.id_corsostudi = 4;
	
SELECT P.id, P.nome, P.cognome, P.telefono
FROM persona P
	JOIN docenza D ON (P.id = D.id_persona)
	JOIN inserogato IE ON (D.id_inserogato = IE.id)
WHERE IE.annoaccademico = '2009/2010' AND IE.modulo = 0 AND IE.id_corsostudi = 4
EXCEPT(SELECT * FROM ES2)
ORDER BY cognome;

-- creo una view con cio che devo togliere.
-- prendo tutti gli insenganti che hanno sostenuto un insegnamento nell'anno indicato
-- con id corso = 4 ma che non sia unita logistica(modulo = 0)
-- e toglo la view dall'insieme

-----------------------ES 3--------------------------
--Trovare identificatore, cognome e nome dei docenti che, nell’anno accademico 2010/2011, hanno tenuto un
--insegnamento (l’attributo da confrontare è nomeins) che non hanno tenuto nell’anno accademico precedente.


CREATE TEMP VIEW ES3 AS
SELECT P.id, P.cognome, P.id, I.nomeins
FROM persona P
	JOIN docenza D ON (P.id = D.id_persona)
	JOIN inserogato IE ON (D.id_inserogato = IE.id)
	JOIN insegn I ON (IE.id_insegn = I.id)
WHERE IE.annoaccademico = '2009/2010';


SELECT DISTINCT P.id, P.cognome, P.id 
FROM persona P
	JOIN docenza D ON (P.id = D.id_persona)
	JOIN inserogato IE ON (D.id_inserogato = IE.id)
	JOIN insegn I ON (IE.id_insegn = I.id)
WHERE IE.annoaccademico = '2010/2011' 
	AND ROW(P.id, I.nomeins) NOT IN(SELECT DISTINCT ES3.id, ES3.LOWER(I.nomeins) FROM ES3)
GROUP BY P.id;
	



-----------------------ES 4---------------------------
--Trovare per ogni periodo di lezione del 2010/2011 la cui descrizione inizia con ’I semestre’ o ’Primo semestre’
--il numero di occorrenze di insegnamento allocate in quel periodo. Si visualizzi quindi: l’abbreviazione, il
--discriminante, inizio, fine e il conteggio richiesto ordinati rispetto all’inizio e fine.

SELECT PL.abbreviazione, PDD.discriminante, PDD.inizio, PDD.fine, COUNT (*) AS InsPrimoSemstre 
FROM periododid AS PDD 
	JOIN Insinperiodo IIP ON (PDD.id = IIP.id_periodolez)
	JOIN Inserogato IE ON (IIP.id_inserogato = IE.id)
	JOIN PeriodoLez PL ON (IIP.id_periodolez = PL.id)
WHERE (PDD.descrizione ILIKE 'I semestre' OR PDD.descrizione ILIKE 'Primo semestre') AND IE.annoaccademico = '2010/2011'
GROUP BY (PL.abbreviazione, PDD.discriminante, PDD.inizio, PDD.fine)
ORDER BY (PDD.inizio, PDD.fine);


-----------------------ES 5---------------------------
--Trovare, per ogni facoltà, il numero di unità logistiche erogate (modulo < 0) e il numero corrispondente di
--crediti totali erogati nel 2010/2011, riportando il nome della facoltà e i conteggi richiesti. Usare pure la
--relazione diretta tra InsErogato e Facolta.

SELECT F.nome AS NomeFacolta, COUNT (IE.modulo) AS NumeroUnitaLogistiche, COUNT (IE.crediti) AS CreditiTotaliErogati
FROM facolta F
	JOIN inserogato IE ON (F.id = IE.id_facolta)
WHERE IE.annoaccademico = '2010/2011' AND IE.modulo < 0
GROUP BY F.nome;



-----------------------ES 6---------------------------
--Trovare i corsi di studio che non sono gestiti dalla facoltà di “Medicina e Chirurgia” e che hanno insegnamenti
--erogati con moduli nel 2010/2011. Si visualizzi il nome del corso e il numero di insegnamenti erogati con
--moduli nel 2010/2011.

SELECT DISTINCT CS.nome, COUNT(*) AS NumeroInsErogati
FROM corsostudi CS
	JOIN inserogato IE ON (CS.id = IE.id_corsostudi)
	JOIN facolta F ON (IE.id_facolta = F.id)
WHERE IE.annoaccademico = '2010/2011' AND 
	F.nome NOT ILIKE 'Medicina e Chirurgia' AND
	IE.modulo > 0
GROUP BY CS.nome;



-----------------------ES 7---------------------------
--Trovare gli insegnamenti del corso di studi con id=4 che non sono mai stati offerti al secondo quadrimestre.
--Per selezionare il secondo quadrimestre usare la condizione "abbreviazione LIKE '2%' ".

DROP VIEW ES7;
CREATE TEMP VIEW ES7 AS
SELECT I.nomeins, I.id
FROM Insegn I
	JOIN inserogato IE ON (I.id = IE.id_insegn)
	JOIN corsostudi CS ON (IE.id_corsostudi = CS.id)
	JOIN insinperiodo IIN ON (IE.id = IIN.id_inserogato)
	JOIN periodolez PL ON (IIN.id_periodolez = PL.id)
WHERE CS.id = 4 AND PL.abbreviazione LIKE '2%';

SELECT LOWER(I.nomeins), I.id
FROM insegn I
	JOIN inserogato IE ON (I.id = IE.id_insegn)
	JOIN corsostudi CS ON (IE.id_corsostudi = CS.id)
WHERE CS.id = 4
EXCEPT(
SELECT LOWER(nomeins), id FROM ES7);


-----------------------ES 8---------------------------
--ES 8
-- devo creare una view quando ho un join tra tante tabelle. il join aumenta il costo
--Trovare, per ogni facoltà, il docente che ha tenuto il numero massimo di ore di lezione nel 2009/2010, riportando
--il cognome e il nome del docente e la facoltà. Per la relazione tra InsErogato e Facolta usare la relazione
--diretta.
--La soluzione ha 10 righe. si è corretto ci sono 3 tuple che hanno lo stesso massimo

DROP VIEW ES8;
CREATE TEMP VIEW ES8 AS
	SELECT DISTINCT P.id AS idP, P.nome AS nomeP, P.cognome AS cognomeP, F.id  AS idF, F.nome AS nomeF, SUM(D.orelez) AS oretot
	FROM Persona P
		JOIN Docenza D ON(P.id= D.id_persona)
		JOIN InsErogato IE ON(D.id_inserogato = IE.id)
		JOIN Facolta F ON(IE.id_facolta = F.id)
	WHERE	IE.annoaccademico = '2009/2010'
	GROUP BY(idP, nomeP, cognomeP, idF, nomeF);

SELECT cognomep, nomep, nomefacolta, maxore
FROM(SELECT nomeF, MAX(oretot) AS maxore FROM ES8 GROUP BY(nomeF)) AS subquery --mettere alias
	JOIN (SELECT nomeP, cognomeP,nomeF AS nomefacolta, oretot FROM ES8) AS subquery2 --mettere alias per la subquery
		ON subquery.nomeF = subquery2.nomefacolta AND subquery.maxore = subquery2.oretot

ORDER BY(cognomep)


-----------------------ES 9---------------------------
--Trovare gli insegnamenti (esclusi i moduli e le unità logistiche) del corso di studi con id=240 erogati nel
--2009/2010 e nel 2010/2011 che non hanno avuto docenti di nome ’Roberto’, ’Alberto’, ’Massimo’ o ’Luca’
--in entrambi gli anni accademici, riportando il nome, il discriminante dell’insegnamento, ordinati per nome
--insegnamento.
DROP VIEW ES9;
CREATE TEMP VIEW ES9 AS
	(SELECT IE.id, I.nomeins, DI.nome AS discriminante, IE.annoaccademico
		FROM Persona P
			JOIN Docenza D ON(P.id = D.id_persona)
			JOIN InsErogato IE ON(D.id_inserogato = IE.id)
	 		JOIN Insegn I ON(IE.id_insegn = I.id)
	 		JOIN Discriminante DI ON(IE.id_discriminante = DI.id)

		WHERE IE.id_corsostudi = 240
			AND IE.modulo = 0
			AND P.nome  NOT IN('Roberto', 'Alberto', 'Massimo', 'Luca'));

SELECT nomeins, discriminante
FROM ES9
WHERE annoaccademico = '2009/2010'
	INTERSECT (SELECT nomeins, discriminante FROM ES9 WHERE annoaccademico = '2010/2011');

-----------------------ES 10---------------------------
--Trovare le unità logistiche del corso di studi con id=420 erogati nel 2010/2011 e che hanno lezione o il
--lunedì (Lezione.giorno=2) o il martedì (Lezione.giorno=3), ma non in entrambi i giorni, riportando il nome
--dell’insegnamento e il nome dell’unità ordinate per nome insegnamento.

SELECT I.nomeins, IE.nomemodulo
FROM Insegn I
	JOIN InsErogato IE ON (I.id = IE.id_insegn)
WHERE IE.id_corsostudi = 420 AND
	IE.annoaccademico = '2010/2011' AND
	IE.modulo >=0 AND
	IE.id IN(
		(SELECT L1.id_inserogato
		FROM Lezione L1 
			JOIN LEzione L2 ON(L2.id_inserogato = L1.id_inserogato)
		WHERE (L1.giorno = 2 OR L2.giorno = 3))
		EXCEPT
		(SELECT L1.id_inserogato
		FROM Lezione L1 
			JOIN LEzione L2 ON(L2.id_inserogato = L1.id_inserogato)
		WHERE (L1.giorno = 2 AND L2.giorno = 3))
	);



-----------------------ES 11--------------------------
--Trovare il nome dei corsi di studio che non hanno mai erogato insegnamenti che contengono nel nome la
--stringa ’matematica’ (usare ILIKE invece di LIKE per rendere il test non sensibile alle maiuscole/minuscole
--(case-insensitive)).

SELECT DISTINCT nome 
FROM corsostudi 
WHERE ROW(id) NOT IN (
	SELECT CS.id
	FROM corsostudi CS 
		JOIN inserogato IE ON (CS.id = IE.id_corsostudi)
		JOIN insegn I ON (IE.id_insegn = I.id)
	WHERE I.nomeins ILIKE '%matematica%'
	);

--oppure
--DROP VIEW ES11;	
--CREATE TEMP VIEW ES11 AS
--SELECT CS.id
--	FROM corsostudi CS 
	--	JOIN inserogato IE ON (CS.id = IE.id_corsostudi)
		--JOIN insegn I ON (IE.id_insegn = I.id)
	--WHERE I.nomeins ILIKE '%matematica%';

--SELECT nome 
--FROM corsostudi
--WHERE id NOT IN (SELECT * FROM ES11)

-----------------------ES 12--------------------------
--Trovare gli insegnamenti (esclusi moduli e unità logistiche) dei corsi di studi della facoltà di ’Scienze Matematiche
--Fisiche e Naturali’ che sono stati tenuti dallo stesso docente per due anni accademici consecutivi
--riportando il nome dell’insegnamento, il nome e il cognome del docente.
--Per la relazione tra InsErogato e Facolta non usare la relazione diretta.
--Circa la condizione sull’anno accademico, dopo aver estratto una sua opportuna parte, si può trasformare questa
--in un intero e, quindi, usarlo per gli opportuni controlli. Oppure si può usarla direttamente confrontandola
--con un’opportuna parte dell’altro anno accademico.
--La soluzione ha 535 righe.
DROP VIEW ES12;
CREATE TEMP VIEW ES12 AS(
	SELECT I.nomeins AS insegnname, P.nome AS nomeP, P.cognome AS cognomeP, CAST(Substring(IE.annoaccademico FROM 6 for 4)AS INTEGER)  as anno
	FROM Insegn I 
		JOIN InsErogato IE ON (I.id = IE.id_insegn)
		JOIN Facolta F ON(IE.id_facolta = F.id)
		JOIN Docenza D ON(IE.id = D.id_inserogato)
		JOIN Persona P ON(D.id_persona = P.id)
	WHERE F.nome ILIKE 'Scienze Matematiche Fisiche e Naturali'
	AND IE.modulo = 0
	ORDER BY nomeins, anno
);

SELECT DISTINCT E.insegnname, E.nomeP, E.cognomeP
FROM ES12 E
	JOIN ES12 subquery ON(E.insegnname = subquery.insegnname AND E.nomeP = subquery.nomeP AND E.cognomeP = subquery.cognomeP)
WHERE E.anno - subquery.anno = 1



-----------------------ES 13---------------------------
--Trovare per ogni segreteria che serve almeno un corso di studi il numero di corsi di studi serviti, riportando il
--nome della struttura, il suo numero di fax e il conteggio richiesto.

SELECT SS.nomestruttura, SS.fax, COUNT (SS.id)
FROM strutturaservizio SS
	JOIN corsostudi CS ON (SS.id = CS.id_segreteria)
GROUP BY (SS.nomestruttura, SS.fax);


-----------------------ES 14---------------------------
--Considerando solo l’anno accademico 2010/2011, trovare i docenti che hanno insegnato per un numero totale
--di crediti di lezione maggiore della media dei crediti totali insegnati (lezione) da tutti i docenti nell’anno
--accademico. I crediti insegnati sono specificati nella tabella Docenza. Per calcolare la somma o la media, si
--devono considerare solo le ’docenze’ che hanno creditilez significativi e diversi da 0 (per rendere la selezione
--un po’ più significativa)

DROP VIEW somma;
CREATE TEMP VIEW somma AS
SELECT D.id_persona, SUM(D.creditilez) AS sommacrediti
FROM docenza D 
	JOIN inserogato IE ON (D.id_inserogato = IE.id)
WHERE IE.annoaccademico = '2010/2011' AND D.creditilez > 0
GROUP BY D.id_persona;

SELECT DISTINCT D.id_persona, S.sommacrediti
FROM docenza D 
	JOIN somma S ON (D.id_persona = s.id_persona)
WHERE S.sommacrediti > (SELECT AVG (sommacrediti) FROM somma);

-----------------------ES 15---------------------------
--Trovare per ogni docente il numero di insegnamenti o moduli o unità logistiche a lui assegnate come docente
--nell’anno accademico 2005/2006, riportare anche coloro che non hanno assegnato alcun insegnamento. Nel
--risultato si mostri identificatore, nome e cognome del docente insieme al conteggio richiesto (0 per il caso
--nessun insegnamento/modulo/unità insegnati).

DROP VIEW modmagg0;
CREATE TEMP VIEW modmagg0 AS(
SELECT P.nome, P.cognome, COUNT(ALL IE.id) as Num, P.id
FROM Docenza D 
	RIGHT JOIN InsErogato IE ON(IE.id = D.id_inserogato)
	JOIN Persona P ON (D.id_persona = P.id)
WHERE IE.annoaccademico = '2005/2006'
GROUP BY(P.nome, P.cognome, P.id));


SELECT P.nome, P.cognome, 0 as Num
FROM Persona P
WHERE P.id IN(SELECT D1.id_persona
				FROM Docenza D1) AND
	P.id NOT IN(SELECT id FROM modmagg0)
UNION(
	SELECT nome, cognome, Num FROM modmagg0
	);





































